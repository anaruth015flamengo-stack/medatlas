MedAtlas Tórax — Etapa 1

Copie a pasta atlas-torax para a raiz do repositório medatlas, preservando index.html.
Acesse https://anaruth015flamengo-stack.github.io/medatlas/atlas-torax/

O mapa interativo é uma ilustração educacional, não uma TC real.
O módulo TC real permite carregar localmente pares NIfTI compatíveis e JSON de rótulos.
Este pacote não altera atlas-radiologia nem a página inicial do repositório.
